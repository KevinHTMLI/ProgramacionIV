﻿namespace ExamenProgramacionll._InsertarControlador_
{
    public class ClassCRSA
    {
        public int NumeroEspacio { get; set; }

        public string TipoVehiculo { get; set; }

        public string Placa { get; set; }

        public string NombreCompleto { get; set; }

        public string Email { get; set; }

        public DateTime Fecha_HoraEntrada { get; set; }

        public int CantidadHoras { get; set; }

        //Metodo para calcular el costo del parqueo
        public decimal CalcularMontoPago
        {
            get
            {
                // Definir el costo por hora
                decimal costoPorHora = 1200;// Ejemplo: ₡1200 por hora
                // Calcular el costo total
                decimal costoTotal = CantidadHoras * costoPorHora;
                return costoTotal;
            }
        }
    }
}
