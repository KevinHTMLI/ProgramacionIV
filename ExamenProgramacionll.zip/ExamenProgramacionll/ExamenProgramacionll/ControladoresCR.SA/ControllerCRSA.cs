﻿using ExamenProgramacionll._InsertarControlador_;
using Microsoft.AspNetCore.DataProtection.KeyManagement;
using Microsoft.AspNetCore.Mvc;

namespace ExamenProgramacionll.Controllers
{
    [ApiController] //Permite al controlador usar los verbos del protocolo HPPT
    [Route("[Controller]")] //Implementacion de rutas para el manejo de metodos

    public class ControllerCRSA : ControllerBase
    {
        //Declarar una lista para almacenar objects
        public static List<ClassCRSA> lista = null;

        //Constructor por omision
        //Se ejecuta de primero
        public ControllerCRSA()
        {
            //Validacion se pregunta si esta vacia
            if (lista == null)
            {
                //Si esta vacia se inicializa
                lista = new List<ClassCRSA>();

                LlenarLista();
            }

        }

        private void LlenarLista()
        {
            //Agregar objetos a la lista
            lista.Add(new ClassCRSA
            {
                NumeroEspacio = 5,
                TipoVehiculo = "Electrico",
                Placa = "ABC-123",
                NombreCompleto = "Juan Pérez",
                Email = "juan.perez@hotmail.com",
                Fecha_HoraEntrada = DateTime.Now.AddHours(-3), // Entró hace 3 horas
                CantidadHoras = 3
                // No es necesario asignar CalcularMontoPago, ya que es una propiedad calculada
            });

            lista.Add(new ClassCRSA
            {
                NumeroEspacio = 10,
                TipoVehiculo = "Híbrido",
                Placa = "XYZ-456",
                NombreCompleto = "María López",
                Email = "maria.gomez@gmail.com",
                Fecha_HoraEntrada = DateTime.Now.AddHours(-1), // Entró hace 1 horas
                CantidadHoras = 1
            });
        }

        //Metodos Public para la API

        //Metodo para obtener todos los objetos de la lista
        [HttpGet]
        [Route("list")]
        public List<ClassCRSA> list()
        {
            //Retorna la lista de objetos
            return lista;
        }

        //Metodo encargado de guardar un nuevo vehiculo en la lista
        [HttpPut]
        [Route("Save")]
        public string Save(ClassCRSA c)
        {
            string msj = "Vehiculo guardado con exito";

            if (c == null)
            {
                msj = "Error: El vehiculo no puede ser guardado";
            }
            else
            {
                //Agregar el objeto a la lista
                lista.Add(c);
            }
            return msj;
        }
        //Metodo encargado de eliminar un vehiculo de la lista
        [HttpDelete]
        [Route("Delete")]
        public string Delete(int NumeroEspacio)
        {
            //Mensaje al usuario
            string msj = "Vehiculo eliminado con exito";

            //se busca el objeto en la lista por medio del numero de espacio
            ClassCRSA temp = lista.FirstOrDefault(x => x.NumeroEspacio == NumeroEspacio);

            //se valida si hay datos existentes
            if (temp == null)
            {
                //si no hay datos se retorna un mensaje de error
                msj = "Error: El vehiculo no existe en la lista";
            }
            else
            {
                //si hay datos se elimina el objeto de la lista
                lista.Remove(temp);
            }
            return msj;
        }

        [HttpPost]
        [Route("Update")]
        public string Update(ClassCRSA c)
        {
            //Mensaje al usuario
            string msj = "Vehiculo actualizado con exito..!";
            //se busca el objeto en la lista por medio del numero de espacio
            ClassCRSA temp = lista.FirstOrDefault(x => x.NumeroEspacio == c.NumeroEspacio);
            //se valida si hay datos existentes
            if (temp == null)
            {
                //si no hay datos se retorna un mensaje de error
                msj = "Error: El vehiculo no existe en la lista";
            }
            else
            {
                //si hay datos se actualiza el objeto en la lista
                temp.TipoVehiculo = c.TipoVehiculo;
                temp.Placa = c.Placa;
                temp.NombreCompleto = c.NombreCompleto;
                temp.Email = c.Email;
                temp.Fecha_HoraEntrada = c.Fecha_HoraEntrada;
                temp.CantidadHoras = c.CantidadHoras;
            }
            return msj;
        }
        [HttpGet]
        [Route("Search")]
        public ClassCRSA Search(int NumeroEspacio)
        {
            //Buscar el objeto en la lista por medio del numero de espacio
            return lista.FirstOrDefault(x => x.NumeroEspacio == NumeroEspacio);
            //Retornar el objeto encontrado o null si no se encuentra
        }
    }


}
